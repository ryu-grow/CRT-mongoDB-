require('dotenv').config();
const app=require('./app');const {connectDB}=require('./config/db');
const port=process.env.PORT||5000;
connectDB().then(()=>app.listen(port,()=>console.log(`Vehicle Service API running on port ${port}`)))
.catch(err=>{console.error('Database connection failed:',err.message);process.exit(1);});
