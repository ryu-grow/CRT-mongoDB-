const mongoose = require('mongoose');
const vehicleSchema = new mongoose.Schema({
  ownerName: {type:String, required:true, trim:true, maxlength:100},
  ownerEmail: {type:String, required:true, trim:true, lowercase:true},
  phone: {type:String, required:true, trim:true},
  registrationNumber: {type:String, required:true, trim:true, uppercase:true, unique:true},
  make: {type:String, required:true, trim:true},
  model: {type:String, required:true, trim:true},
  year: {type:Number, required:true, min:1950, max:2100},
  fuelType: {type:String, enum:['petrol','diesel','electric','hybrid','cng'], required:true},
  odometerKm: {type:Number, default:0, min:0}
}, {timestamps:true});
vehicleSchema.index({ownerEmail:1, createdAt:-1});
vehicleSchema.index({make:1, model:1, year:1});
vehicleSchema.index({registrationNumber:1}, {unique:true});
module.exports = mongoose.model('Vehicle', vehicleSchema);
