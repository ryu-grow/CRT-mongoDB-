const mongoose = require('mongoose');
const serviceJobSchema = new mongoose.Schema({
  vehicle: {type:mongoose.Schema.Types.ObjectId, ref:'Vehicle', required:true},
  serviceType: {type:String, enum:['general-service','oil-change','brake-repair','engine-repair','tyre-change','electrical','other'], required:true},
  complaint: {type:String, required:true, trim:true, maxlength:1500},
  assignedTechnician: {type:String, required:true, trim:true},
  scheduledAt: {type:Date, required:true},
  completedAt: {type:Date},
  status: {type:String, enum:['booked','in-progress','waiting-for-parts','completed','cancelled'], default:'booked'},
  estimatedCost: {type:Number, required:true, min:0},
  finalCost: {type:Number, min:0},
  partsUsed: [{name:{type:String, required:true}, quantity:{type:Number, min:1}, unitPrice:{type:Number, min:0}}],
  notes: {type:String, default:''}
}, {timestamps:true});
serviceJobSchema.index({vehicle:1, scheduledAt:-1});
serviceJobSchema.index({status:1, scheduledAt:1});
serviceJobSchema.index({assignedTechnician:1, status:1});
serviceJobSchema.index({serviceType:1, scheduledAt:-1});
module.exports = mongoose.model('ServiceJob', serviceJobSchema);
