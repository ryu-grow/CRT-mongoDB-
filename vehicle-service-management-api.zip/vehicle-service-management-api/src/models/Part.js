const mongoose = require('mongoose');
const partSchema = new mongoose.Schema({
  sku:{type:String, required:true, unique:true, uppercase:true, trim:true},
  name:{type:String, required:true, trim:true},
  category:{type:String, required:true},
  quantityInStock:{type:Number, required:true, min:0, default:0},
  reorderLevel:{type:Number, required:true, min:0, default:5},
  unitPrice:{type:Number, required:true, min:0},
  supplier:{type:String, default:''}
}, {timestamps:true});
partSchema.index({category:1, name:1});
partSchema.index({quantityInStock:1, reorderLevel:1});
module.exports = mongoose.model('Part', partSchema);
