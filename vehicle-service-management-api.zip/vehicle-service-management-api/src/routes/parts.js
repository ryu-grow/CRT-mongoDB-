const express=require('express');
const Part=require('../models/Part');
const router=express.Router();
const wrap=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
router.post('/',wrap(async(req,res)=>{const data=await Part.create(req.body);res.status(201).json({success:true,data});}));
router.get('/',wrap(async(req,res)=>{
  const filter={};
  if(req.query.category) filter.category=req.query.category;
  if(req.query.lowStock==='true') filter.$expr={$lte:['$quantityInStock','$reorderLevel']};
  const data=await Part.find(filter).sort({name:1}).limit(200).lean();
  res.json({success:true,data});
}));
router.patch('/:id',wrap(async(req,res)=>{
  const data=await Part.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});
  if(!data) return res.status(404).json({success:false,message:'Part not found'});
  res.json({success:true,data});
}));
router.delete('/:id',wrap(async(req,res)=>{
  const data=await Part.findByIdAndDelete(req.params.id);
  if(!data) return res.status(404).json({success:false,message:'Part not found'});
  res.json({success:true,message:'Part deleted'});
}));
module.exports=router;
