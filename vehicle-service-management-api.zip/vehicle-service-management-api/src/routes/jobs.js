const express=require('express');
const mongoose=require('mongoose');
const Vehicle=require('../models/Vehicle');
const ServiceJob=require('../models/ServiceJob');
const router=express.Router();
const wrap=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);

router.post('/',wrap(async(req,res)=>{
  if(!mongoose.isValidObjectId(req.body.vehicle)) return res.status(400).json({success:false,message:'Valid vehicle id is required'});
  const vehicle=await Vehicle.findById(req.body.vehicle);
  if(!vehicle) return res.status(404).json({success:false,message:'Vehicle not found'});
  const data=await ServiceJob.create(req.body);
  res.status(201).json({success:true,data});
}));
router.get('/',wrap(async(req,res)=>{
  const filter={};
  if(req.query.vehicle) filter.vehicle=req.query.vehicle;
  if(req.query.status) filter.status=req.query.status;
  if(req.query.technician) filter.assignedTechnician=req.query.technician;
  if(req.query.from||req.query.to) filter.scheduledAt={...(req.query.from?{$gte:new Date(req.query.from)}:{}),...(req.query.to?{$lte:new Date(req.query.to)}:{})};
  const data=await ServiceJob.find(filter).populate('vehicle','registrationNumber make model ownerName').sort({scheduledAt:-1}).limit(100);
  res.json({success:true,data});
}));
router.get('/reports/technician-workload',wrap(async(req,res)=>{
  const data=await ServiceJob.aggregate([
    {$match:{status:{$in:['booked','in-progress','waiting-for-parts']}}},
    {$group:{_id:'$assignedTechnician',activeJobs:{$sum:1},estimatedRevenue:{$sum:'$estimatedCost'}}},
    {$sort:{activeJobs:-1}}
  ]);
  res.json({success:true,data});
}));
router.get('/:id',wrap(async(req,res)=>{
  const data=await ServiceJob.findById(req.params.id).populate('vehicle','registrationNumber make model ownerName');
  if(!data) return res.status(404).json({success:false,message:'Service job not found'});
  res.json({success:true,data});
}));
router.patch('/:id',wrap(async(req,res)=>{
  const data=await ServiceJob.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});
  if(!data) return res.status(404).json({success:false,message:'Service job not found'});
  res.json({success:true,data});
}));
router.delete('/:id',wrap(async(req,res)=>{
  const data=await ServiceJob.findByIdAndDelete(req.params.id);
  if(!data) return res.status(404).json({success:false,message:'Service job not found'});
  res.json({success:true,message:'Service job deleted'});
}));
module.exports=router;
