const express=require('express');
const mongoose=require('mongoose');
const Vehicle=require('../models/Vehicle');
const ServiceJob=require('../models/ServiceJob');
const router=express.Router();
const wrap=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);

// CREATE vehicle
router.post('/',wrap(async(req,res)=>{const vehicle=await Vehicle.create(req.body);res.status(201).json({success:true,data:vehicle});}));
// READ vehicles with filters, pagination and text-like regex lookup
router.get('/',wrap(async(req,res)=>{
  const page=Math.max(parseInt(req.query.page)||1,1),limit=Math.min(Math.max(parseInt(req.query.limit)||10,1),100);
  const filter={};
  if(req.query.ownerEmail) filter.ownerEmail=req.query.ownerEmail.toLowerCase();
  if(req.query.make) filter.make=new RegExp(`^${req.query.make.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}$`,'i');
  if(req.query.registrationNumber) filter.registrationNumber=req.query.registrationNumber.toUpperCase();
  const [data,total]=await Promise.all([Vehicle.find(filter).sort({createdAt:-1}).skip((page-1)*limit).limit(limit).lean(),Vehicle.countDocuments(filter)]);
  res.json({success:true,data,pagination:{page,limit,total,pages:Math.ceil(total/limit)}});
}));
router.get('/:id',wrap(async(req,res)=>{
  if(!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({success:false,message:'Invalid vehicle id'});
  const data=await Vehicle.findById(req.params.id).lean();
  if(!data) return res.status(404).json({success:false,message:'Vehicle not found'});
  res.json({success:true,data});
}));
// UPDATE vehicle
router.patch('/:id',wrap(async(req,res)=>{
  const data=await Vehicle.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});
  if(!data) return res.status(404).json({success:false,message:'Vehicle not found'});
  res.json({success:true,data});
}));
// DELETE vehicle and service history
router.delete('/:id',wrap(async(req,res)=>{
  const data=await Vehicle.findByIdAndDelete(req.params.id);
  if(!data) return res.status(404).json({success:false,message:'Vehicle not found'});
  await ServiceJob.deleteMany({vehicle:data._id});
  res.json({success:true,message:'Vehicle and associated service jobs deleted'});
}));
module.exports=router;
