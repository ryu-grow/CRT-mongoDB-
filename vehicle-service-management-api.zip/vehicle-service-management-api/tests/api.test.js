const {test,before,after}=require('node:test');
const assert=require('node:assert/strict');
const mongoose=require('mongoose');
const {MongoMemoryServer}=require('mongodb-memory-server');
const request=require('supertest');
const app=require('../src/app');
let mongo;
before(async()=>{mongo=await MongoMemoryServer.create();await mongoose.connect(mongo.getUri());});
after(async()=>{await mongoose.disconnect();if(mongo) await mongo.stop();});
test('health endpoint',async()=>{const r=await request(app).get('/health');assert.equal(r.status,200);assert.equal(r.body.success,true);});
test('vehicle and service job CRUD workflow',async()=>{
 const vehicle=await request(app).post('/api/vehicles').send({
  ownerName:'Neha Verma',ownerEmail:'neha@example.com',phone:'9876543210',
  registrationNumber:'RJ14AB1234',make:'Maruti Suzuki',model:'Swift',year:2022,fuelType:'petrol',odometerKm:18000
 });
 assert.equal(vehicle.status,201);const id=vehicle.body.data._id;
 const list=await request(app).get('/api/vehicles?make=Maruti%20Suzuki');
 assert.equal(list.status,200);assert.equal(list.body.pagination.total,1);
 const job=await request(app).post('/api/jobs').send({
  vehicle:id,serviceType:'general-service',complaint:'Routine maintenance and inspection',
  assignedTechnician:'Amit',scheduledAt:'2027-02-10T09:00:00.000Z',estimatedCost:3500,status:'booked'
 });
 assert.equal(job.status,201);
 const update=await request(app).patch(`/api/jobs/${job.body.data._id}`).send({status:'completed',finalCost:3300});
 assert.equal(update.status,200);assert.equal(update.body.data.status,'completed');
 const del=await request(app).delete(`/api/vehicles/${id}`);
 assert.equal(del.status,200);
});
test('parts inventory CRUD',async()=>{
 const part=await request(app).post('/api/parts').send({sku:'OIL-5W30',name:'Engine Oil 5W-30',category:'Lubricants',quantityInStock:12,reorderLevel:5,unitPrice:900,supplier:'Auto Supplies'});
 assert.equal(part.status,201);
 const low=await request(app).get('/api/parts?lowStock=true');
 assert.equal(low.status,200);assert.equal(low.body.data.length,0);
 const updated=await request(app).patch(`/api/parts/${part.body.data._id}`).send({quantityInStock:3});
 assert.equal(updated.body.data.quantityInStock,3);
});
