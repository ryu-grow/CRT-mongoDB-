# Vehicle Service & Workshop Management API

A MongoDB-backed REST API for an automobile workshop. It manages customer vehicles, service/repair jobs, technicians and spare-parts inventory. It is an individual backend/database project and does not use bank management, student placement management, or event management.

## Main modules

- **Vehicle management:** register, list, search/filter, update and delete vehicles.
- **Service job management:** book repair jobs, assign technicians, track job status, record estimated/final costs and parts used.
- **Parts inventory:** create, list, update and delete parts; filter items at or below their reorder level.
- **Reports:** technician workload aggregation using MongoDB aggregation pipeline.
- **Database engineering:** compound and unique indexes for common access patterns.
- **Operations:** three-member MongoDB replica set, backup/restore scripts, Docker deployment and automated tests.

## Technology

Node.js 20+, Express, MongoDB 7, Mongoose, Docker Compose, Supertest and `node:test`.

## Run locally

1. Install Node.js 20+ and MongoDB Community Server.
2. Copy `.env.example` to `.env`.
3. Set `MONGODB_URI=mongodb://127.0.0.1:27017/vehicle_service`.
4. Run:

```bash
npm install
npm run dev
```

Health check: `http://localhost:5000/health`

## Run with MongoDB replication

Docker Compose launches three MongoDB members and initializes replica set `rs0` before starting the API:

```bash
docker compose up --build
```

Check replica status:

```bash
docker compose exec mongo1 mongosh --eval "rs.status()"
```

Stop services:

```bash
docker compose down
```

The database uses persistent Docker volumes. `docker compose down -v` removes those volumes and permanently deletes their data.

## REST API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | API health check |
| POST | `/api/vehicles` | Add vehicle |
| GET | `/api/vehicles` | List/filter vehicles |
| GET | `/api/vehicles/:id` | View vehicle |
| PATCH | `/api/vehicles/:id` | Update vehicle |
| DELETE | `/api/vehicles/:id` | Delete vehicle and its jobs |
| POST | `/api/jobs` | Create service job |
| GET | `/api/jobs` | Filter/list jobs |
| GET | `/api/jobs/:id` | View job |
| PATCH | `/api/jobs/:id` | Update job status/cost |
| DELETE | `/api/jobs/:id` | Delete job |
| GET | `/api/jobs/reports/technician-workload` | Technician workload report |
| POST | `/api/parts` | Add spare part |
| GET | `/api/parts` | List/filter parts |
| PATCH | `/api/parts/:id` | Update part/stock |
| DELETE | `/api/parts/:id` | Delete part |

### Example: create a vehicle

```json
{
  "ownerName": "Neha Verma",
  "ownerEmail": "neha@example.com",
  "phone": "9876543210",
  "registrationNumber": "RJ14AB1234",
  "make": "Maruti Suzuki",
  "model": "Swift",
  "year": 2022,
  "fuelType": "petrol",
  "odometerKm": 18000
}
```

### Example: create a service job

Replace `VEHICLE_ID` with the id returned from vehicle creation.

```json
{
  "vehicle": "VEHICLE_ID",
  "serviceType": "general-service",
  "complaint": "Routine maintenance and inspection",
  "assignedTechnician": "Amit",
  "scheduledAt": "2027-02-10T09:00:00.000Z",
  "estimatedCost": 3500,
  "status": "booked"
}
```

### Useful query examples

```http
GET /api/vehicles?make=Maruti%20Suzuki&page=1&limit=10
GET /api/vehicles?ownerEmail=neha@example.com
GET /api/jobs?status=in-progress&technician=Amit
GET /api/jobs?from=2027-02-01&to=2027-02-28
GET /api/parts?lowStock=true
GET /api/jobs/reports/technician-workload
```

## Indexing and query optimization

Indexes are declared in the Mongoose schemas:

| Index | Purpose |
|---|---|
| `registrationNumber` unique | Fast vehicle lookup and duplicate prevention |
| `{ownerEmail:1, createdAt:-1}` | Customer vehicle history |
| `{make:1, model:1, year:1}` | Vehicle model search |
| `{vehicle:1, scheduledAt:-1}` | Service history per vehicle |
| `{status:1, scheduledAt:1}` | Find jobs by status/date |
| `{assignedTechnician:1, status:1}` | Technician workload |
| `{category:1, name:1}` | Parts catalogue filtering |
| `{quantityInStock:1, reorderLevel:1}` | Inventory monitoring |

Inspect a query plan in `mongosh`:

```javascript
db.servicejobs.find({status: "booked"})
  .sort({scheduledAt: 1})
  .explain("executionStats")
```

Compare `totalDocsExamined`, `totalKeysExamined` and the winning plan. Indexes should be checked against actual query patterns; excessive indexes increase write cost.

## Replication, backup and restore

The Docker Compose deployment configures a three-member replica set. Replication improves availability, but it is not a backup because accidental changes can replicate to all members.

Install MongoDB Database Tools, then:

```bash
export MONGODB_URI='mongodb://localhost:27017/vehicle_service?replicaSet=rs0'
chmod +x scripts/*.sh
./scripts/backup.sh
```

Restore a selected backup (this drops/replaces matching collections):

```bash
./scripts/restore.sh backups/YYYYMMDD_HHMMSS
```

Recommended operational policy: daily backup, retention of 7 daily and 4 weekly copies, encrypted off-host storage, and periodic restore tests. Keep backups outside GitHub.

## Testing

```bash
npm install
npm test
```

The tests use an in-memory MongoDB and cover health, vehicle CRUD, job creation/update, and spare-parts inventory. The first test run may download a MongoDB binary.

## Deployment

For a local demonstration:

```bash
docker compose up --build -d
curl http://localhost:5000/health
```

For public hosting, use a managed MongoDB replica set such as MongoDB Atlas and deploy the Node.js container to a container platform. Configure `MONGODB_URI` as a secret. Never commit `.env` or database credentials.

## GitHub upload

1. Create a repository named `vehicle-service-management-api`.
2. Extract the ZIP.
3. In the project directory, run `git init`, `git add .`, and `git commit -m "Initial project"`.
4. Add your repository as `origin` and push to `main`.

## Suggested viva/demo flow

1. Register a vehicle and show the generated MongoDB document.
2. Search vehicles by make or owner email.
3. Create a service job and update its status from booked to in-progress/completed.
4. Add spare parts and show low-stock filtering.
5. Display the technician workload aggregation report.
6. Show the schema indexes and `explain("executionStats")`.
7. Show replica-set status and run backup/restore.
8. Run the automated test suite.

## Scope and production considerations

This is an educational backend, not a production workshop platform. Before production, add authentication/role-based access, request validation, rate limiting, audit history, transactional stock deduction, atomic job scheduling, stronger concurrency controls, structured logs and monitoring. Parts listed in a job are descriptive in this starter; inventory is not automatically decremented.
